<?php

namespace WebpConverterVendor\MattPlugins\DeactivationModal\Exception;

/**
 * .
 */
class DuplicatedFormValueKeyException extends \Exception
{
}
